# My Package

A simple package to send messages to a server endpoint.

## Installation

```sh
pip install my-package
