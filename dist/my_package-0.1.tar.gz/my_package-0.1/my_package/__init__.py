# my_package/__init__.py

from .send_message import ServerClient
